import axios from '@nextcloud/axios'
import { generateOcsUrl } from '@nextcloud/router'

async function fetchMessages() {
    try {
        // Replace ROOM_TOKEN with your Talk room token
        const url = generateOcsUrl('apps/spreed/api/v1/chat/ROOM_TOKEN')
        const response = await axios.get(url, {
            headers: {
                'OCS-APIRequest': 'true',
                'Accept': 'application/json'
            }
        })
        return response.data.ocs.data || []
    } catch (e) {
        console.error('Failed to load Talk messages', e)
        return []
    }
}

async function renderWidget() {
    const container = document.createElement('div')
    container.classList.add('section')
    container.innerHTML = `<h3>Talk Messages</h3><p>Loading...</p>`
    document.getElementById('dashboard').appendChild(container)

    const messages = await fetchMessages()
    container.innerHTML = `
        <h3>Talk Messages</h3>
        <ul>
            ${messages.map(msg => `<li><b>${msg.actorDisplayName}</b>: ${msg.message}</li>`).join('')}
        </ul>
    `
}

renderWidget()
