import { createApp } from 'vue';
import TalkWidget from '../src/components/TalkWidget.vue';

const app = createApp(TalkWidget);
app.mount('#talk-dashboard-widget');
