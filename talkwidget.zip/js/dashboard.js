console.log("Talk Dashboard Widget loaded 🚀");

OCA.TalkWidget = {
    init: function () {
        const el = document.createElement('div');
        el.innerHTML = `<h3>Talk Widget</h3><p>Hello from your Dashboard widget!</p>`;
        return el;
    }
};
