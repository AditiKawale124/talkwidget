<?php

namespace OCA\TalkWidget\Dashboard;

use OCP\Dashboard\IDashboardWidget;
use OCP\IL10N;

class TalkWidget implements IDashboardWidget {
    private IL10N $l;

    public function __construct(IL10N $l) {
        $this->l = $l;
    }

    public function getId(): string {
        return 'talkwidget';
    }

    public function getTitle(): string {
        return $this->l->t('Talk Messages');
    }

    public function getIconClass(): string {
        return 'icon-comment';
    }

    public function getOrder(): int {
        return 10;
    }

    public function getUrl(): ?string {
        return null;
    }

    public function load(): array {
        return []; // frontend fetches messages
    }
}
