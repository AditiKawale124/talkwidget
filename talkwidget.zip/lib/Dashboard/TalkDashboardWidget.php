<?php

namespace OCA\TalkWidget\Dashboard;

use OCP\Dashboard\IWidget;
use OCP\IL10N;
use OCP\Util;

class TalkDashboardWidget implements IWidget {
    private IL10N $l;

    public function __construct(IL10N $l) {
        $this->l = $l;
    }

    public function getId(): string {
        return 'talkwidget';
    }

    public function getTitle(): string {
        return $this->l->t('Talk Widget');
    }

    public function getOrder(): int {
        return 10;
    }

    public function getIconClass(): string {
        return 'icon-chat';
    }

    public function load(): void {
        Util::addScript('talkwidget', 'dashboard');
        Util::addStyle('talkwidget', 'dashboard');
    }
}
