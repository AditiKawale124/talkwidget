<?php

namespace OCA\TalkWidget\AppInfo;

use OCP\AppFramework\App;
use OCP\Dashboard\IDashboardManager;
use OCA\TalkWidget\Dashboard\TalkWidget;

class Application extends App {
    public const APP_ID = 'talkwidget';

    public function __construct(array $urlParams = []) {
        parent::__construct(self::APP_ID, $urlParams);
    }

    public function register(): void {
        $container = $this->getContainer();
        $dashboardManager = $container->query(IDashboardManager::class);
        $dashboardManager->registerWidget(TalkWidget::class);
    }
}
