<?php
/** @var array $_ */
script('talkwidget', 'talkwidget.bundle');
style('talkwidget', 'style'); // only if you have CSS
?>
<div id="talkwidget-root"></div>
